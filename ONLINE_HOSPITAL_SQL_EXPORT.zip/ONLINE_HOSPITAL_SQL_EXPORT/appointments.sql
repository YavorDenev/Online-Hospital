-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 05, 2023 at 02:29 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) UNSIGNED NOT NULL,
  `examination` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `doctor_id` int(11) UNSIGNED NOT NULL,
  `patient_id` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `examination`, `date`, `time`, `doctor_id`, `patient_id`) VALUES
(1, 'initial', '2023-03-20', '10:00:00', 1, 10),
(2, 'procedure', '2023-03-19', '09:00:00', 20, 1),
(3, 'initial', '2023-03-27', '16:30:00', 1, 2),
(4, 'initial', '2023-03-27', '09:00:00', 2, 2),
(5, 'secondary', '2023-03-22', '10:00:00', 4, 1),
(6, 'initial', '2023-03-31', '11:30:00', 9, 1),
(7, 'secondary', '2023-03-24', '15:30:00', 2, 5),
(8, 'secondary', '2023-03-25', '11:00:00', 1, 10),
(9, 'procedure', '2023-03-23', '10:00:00', 15, 3),
(10, 'initial', '2023-04-01', '10:00:00', 10, 10),
(11, 'consultation', '2023-03-24', '10:00:00', 3, 2),
(12, 'consultation', '2023-03-20', '13:30:00', 11, 4),
(13, 'initial', '2023-03-21', '09:00:00', 7, 10),
(14, 'initial', '2023-03-26', '17:30:00', 9, 5),
(15, 'procedure', '2023-03-20', '10:30:00', 2, 6),
(16, 'consultation', '2023-03-28', '09:30:00', 4, 7),
(17, 'initial', '2023-03-22', '09:30:00', 19, 9),
(18, 'consultation', '2023-03-28', '11:00:00', 10, 6),
(19, 'initial', '2023-03-23', '16:00:00', 6, 8),
(20, 'procedure', '2023-03-31', '09:00:00', 1, 6),
(21, 'initial', '2023-03-19', '10:00:00', 12, 8),
(22, 'initial', '2023-03-29', '17:00:00', 15, 7),
(23, 'consultation', '2023-03-29', '13:30:00', 18, 11),
(24, 'consultation', '2023-03-23', '15:30:00', 16, 7),
(25, 'consultation', '2023-03-31', '11:00:00', 20, 14),
(26, 'procedure', '2023-03-30', '10:00:00', 17, 7),
(27, 'consultation', '2023-04-01', '10:00:00', 14, 1),
(28, 'initial', '2023-03-27', '10:00:00', 12, 11),
(29, 'consultation', '2023-03-30', '09:30:00', 1, 1),
(30, 'procedure', '2023-03-27', '17:30:00', 2, 2),
(31, 'consultation', '2023-03-28', '10:30:00', 12, 23),
(32, 'initial', '2023-03-23', '14:30:00', 13, 1),
(33, 'initial', '2023-03-26', '10:30:00', 15, 3),
(34, 'consultation', '2023-03-26', '09:30:00', 3, 12),
(35, 'initial', '2023-03-20', '09:00:00', 13, 14),
(36, 'consultation', '2023-03-20', '11:00:00', 4, 13),
(37, 'procedure', '2023-03-25', '09:00:00', 2, 3),
(38, 'consultation', '2023-03-28', '10:30:00', 5, 14),
(39, 'secondary', '2023-03-27', '14:00:00', 7, 32),
(40, 'consultation', '2023-03-30', '17:00:00', 12, 16);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKmujeo4tymoo98cmf7uj3vsv76` (`doctor_id`),
  ADD KEY `FK8exap5wmg8kmb1g1rx3by21yt` (`patient_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `FK8exap5wmg8kmb1g1rx3by21yt` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  ADD CONSTRAINT `FKmujeo4tymoo98cmf7uj3vsv76` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
