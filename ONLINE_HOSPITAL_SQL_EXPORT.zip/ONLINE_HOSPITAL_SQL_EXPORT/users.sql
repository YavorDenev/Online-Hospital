-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2023 at 10:48 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `enabled` bit(1) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  `username` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `enabled`, `password`, `role`, `username`) VALUES
(1, b'1', '$2a$10$M5hr.CmVcBMWD/1OHziInO1gbpqJC5X6MofbVR3m9pJNAD0y3gbZu', 'ROLE_ADMIN', 'admin1'),
(2, b'1', '$2a$10$YjWdtxXODn.sWoStaaET1ecVFHe8mcfXuzeciiqKs8rrfcM9ocz2m', 'ROLE_ADMIN', 'admin2'),
(3, b'1', '$2a$10$pcvt09FaV1G1o7rGCaUiluxAm.TBs3wh2REyF0VshTrPmQFM3ErQy', 'ROLE_DOCTOR', 'doctor1'),
(4, b'1', '$2a$10$VqFQsXFa.UDdCrW45lSSB.qR191SpxNu0QTM.wbCm52MVRHBHATAu', 'ROLE_DOCTOR', 'doctor2'),
(5, b'1', '$2a$10$gRZwXe1el.M2m9xoy4XQb.jzqFI9ROjOG7dqx3CCE0lRZt./ozXyy', 'ROLE_DOCTOR', 'doctor3'),
(6, b'1', '$2a$10$YiyT6AcFJXo3Lut8sR/qUuE37T1bpF/0Lirvfkf64OEyhC1I5LohC', 'ROLE_DOCTOR', 'doctor4'),
(7, b'1', '$2a$10$Ulg2Yi0GIEePCKuNQSh3LOHy20xRLG/D1bUKMzuXNYtJuHdrwKb5a', 'ROLE_DOCTOR', 'doctor5'),
(8, b'1', '$2a$10$jMhSuUgkat1x0dqkdbZyeuaCOTvUZ/2YuIlnneVjGJmhUaj2MGT/2', 'ROLE_DOCTOR', 'doctor6'),
(9, b'1', '$2a$10$J4x3jKoT8YJAabOTahehsOwtBjRVmijpnmSYIwfpZQPdxmpOcHRJe', 'ROLE_DOCTOR', 'doctor7'),
(10, b'1', '$2a$10$Uu8mjT7INgbWzee94mTEAOmKzkComWZuieZyc9jvPtMR6io2SsOkK', 'ROLE_DOCTOR', 'doctor8'),
(11, b'1', '$2a$10$Cd0T9Dw7jGoQwsyaQE7kqOJwvoCNquZK1uiaNhNoH4Z.HnfpRMGSC', 'ROLE_DOCTOR', 'doctor9'),
(12, b'1', '$2a$10$oHip0Y4GdJPzS3a7Dv.QV.KZqEoLahCM4UMkkxdDeUmcudTmYuS32', 'ROLE_DOCTOR', 'doctor10'),
(13, b'1', '$2a$10$5SHtVOw2GoPsjihNe/hGYu5C8m9NPwoOxschnOhZCDCGvVEokOdIC', 'ROLE_DOCTOR', 'doctor11'),
(14, b'1', '$2a$10$SjdJrgVau.XCNZkk00x7n.GKaYI7AQs7jaUKrDLj25kH0NNe3xrMm', 'ROLE_DOCTOR', 'doctor12'),
(15, b'1', '$2a$10$lUUmrS3O0.VQQT5SsgZzsOVCQ60tjDxSDqOqFUy4Tu7WBHD6qFnPS', 'ROLE_DOCTOR', 'doctor13'),
(16, b'1', '$2a$10$88mVnl2jMLS8oKYLm2BZnurl5hXRO4lqCtmb6Yu5MXr5HZG/usLx2', 'ROLE_DOCTOR', 'doctor14'),
(17, b'1', '$2a$10$6XpvB/c7wX0r76Y.meVRteywHPMUY/KKLayANbL.vfaRLFduMMo7.', 'ROLE_DOCTOR', 'doctor15'),
(18, b'1', '$2a$10$cM/uZSntK3Cfc3rte6mLk.zQpK3n8dM82kgJPc6J7EAoIyHGJNei6', 'ROLE_DOCTOR', 'doctor16'),
(19, b'1', '$2a$10$C6uCSSD52246BaGMLa5.5e7/KUu7u13FY/nEpE3KWIZZ2Wee4HIWy', 'ROLE_DOCTOR', 'doctor17'),
(20, b'1', '$2a$10$f/4LZnI4Qgt7UefUYS8KZO/2b24qBp/fabLB0XSvk2B84TtXcXGZ.', 'ROLE_DOCTOR', 'doctor18'),
(21, b'1', '$2a$10$yV8U19yqdg7KAj8pDxrBo.FiLeADR0WATPLn8SqcJVBcUkcFdhhIm', 'ROLE_DOCTOR', 'doctor19'),
(22, b'1', '$2a$10$ul6E31.E9fZ.W5xDD7UAke0skT9znvEMCxez54cojhbxwzm0wZkA2', 'ROLE_DOCTOR', 'doctor20'),
(23, b'1', '$2a$10$guYWRY6NXihvR1AigQzeLOH7rYFZYnKMfiW41J7VLgHerJWmwV2CC', 'ROLE_PATIENT', 'patient1'),
(24, b'1', '$2a$10$B1MbI.hKfpIY7T1yh8muY.wBhvtURYTcA1Rz9Symi12lOZdMHgiai', 'ROLE_PATIENT', 'patient2'),
(25, b'1', '$2a$10$g6WFyRaoCBv.2p0JSRU7m.valMoXjP/dNKypPGZ8EjqdDENWxXlyq', 'ROLE_PATIENT', 'patient3'),
(26, b'1', '$2a$10$2OfN7lMCiM3W9ENBxjF2uO2C.HNzeWQmIc2dNOSl/Wx9C8q3ruFPe', 'ROLE_PATIENT', 'patient4'),
(27, b'1', '$2a$10$vi9wG8olngbFpPwJVnvRZeCP6Sz9nw5lsPLRZPa0Z.D0W4lppQSge', 'ROLE_PATIENT', 'patient5'),
(28, b'1', '$2a$10$lEimpxpUVAlUB4wH66zqBOZ1ZqkWCf1uqNR/odDA/t5TsXgaIf/Ce', 'ROLE_PATIENT', 'patient6'),
(29, b'1', '$2a$10$YCKs7EX6wVeW99689A2efelOa3Ne4A0okYazTlWmIDcN4G61qPLY.', 'ROLE_PATIENT', 'patient7'),
(30, b'1', '$2a$10$T/4/KjwYlsxNQ5owGCO/3.N8V5HdW1VSAwsrJsQBcjWQbcPSUhAQa', 'ROLE_PATIENT', 'patient8'),
(31, b'1', '$2a$10$/6yuFUQ95xo/2REn5trX..8zPQSw3WZhFwOF2E.JAnssWGUDrjRqi', 'ROLE_PATIENT', 'patient9'),
(32, b'1', '$2a$10$DV75szZSTyGM8oZnxKXsIOnkWgcpEIuCpZmoRoySXqjoO8U6ccTNK', 'ROLE_PATIENT', 'patient10'),
(33, b'1', '$2a$10$ErC1LNf92ER8pFrADsPgJufA9pPi3kh3DarjwmWDFvO3/cFiEVXui', 'ROLE_PATIENT', 'patient11'),
(34, b'1', '$2a$10$rtifIITFDuTmyqzpOqsYee0EKib310br6EYvSdW5HBLcdYJnHZCg6', 'ROLE_PATIENT', 'patient12'),
(35, b'1', '$2a$10$1vyUldI330EeiTQZwuZdxe8CUjd0RAie7MF3XP.Q6du529vpipZe.', 'ROLE_PATIENT', 'patient13'),
(36, b'1', '$2a$10$cULEF3avUBZpk7imjl7Vj.y29onwI/StlkbmIFAymAWnj/FRINIs2', 'ROLE_PATIENT', 'patient14'),
(37, b'1', '$2a$10$WxVHynnHVkNztaMN81b0z.tGUDvAWkqiXtE1zgAv0TLXLtOM1F.CW', 'ROLE_PATIENT', 'patient15'),
(38, b'1', '$2a$10$TDk.FPLuvXso0HRQLX8dhOl6/Pfp1N4WLUMYDWbKH2Bo6STj0yXKW', 'ROLE_PATIENT', 'patient16'),
(39, b'1', '$2a$10$wM1feONi4LsMeflvNhqC7OQNmJqhl/ptivwpAdti8xX6LWISW7uqm', 'ROLE_PATIENT', 'patient17'),
(40, b'1', '$2a$10$m3bd87eDgnjiQzY61rjfnezeqSWXnr7r52c4xBPKzhbwMidQ4auqC', 'ROLE_PATIENT', 'patient18'),
(41, b'1', '$2a$10$tymfzC3HG6jMSGm6pow16eigxR3C.6LMKjVvWG5OWJZV4zonhS.F.', 'ROLE_PATIENT', 'patient19'),
(42, b'1', '$2a$10$CMyeZyjuXDOac0QW9g3oT.4zuwG9ZY2fI/v4vjuyKuU1ScvaV2oEq', 'ROLE_PATIENT', 'patient20'),
(43, b'1', '$2a$10$typEdYJE6HHev.E3T8hq2ua7UpBTngd9F19.SqazuA8QtdklHDDIO', 'ROLE_PATIENT', 'patient21'),
(44, b'1', '$2a$10$oS4QzP6f6hfsUwRdjir/3.z4mLNDTdlGXUj7Np1iWTKhWLwAmZ6v6', 'ROLE_PATIENT', 'patient22'),
(45, b'1', '$2a$10$KZexOCYGuLKkTqFLOfUbluLpfAJyxH6IHKeTmd8TXnBJ1LtMrM6S6', 'ROLE_PATIENT', 'patient23'),
(46, b'1', '$2a$10$XhUNKVmm4V3BDXcvIuVQ6eLFZRzoGuYDoH/yBuSNRTt1l8/yOB3nW', 'ROLE_PATIENT', 'patient24'),
(47, b'1', '$2a$10$97ntr8ElqqvqU55cv6hgUOqBJzjaz0jPDV86KRHGk9AgkS3bkXD9C', 'ROLE_PATIENT', 'patient25'),
(48, b'1', '$2a$10$GT4RLkKhnVj0Vfr8WMsdYucXYPtw0ii3tlfXG5qClGuUPR.gmw2Fi', 'ROLE_PATIENT', 'patient26'),
(49, b'1', '$2a$10$ZvbRAI/4Q5K/HOe3DlqDqObVcombSLH0YNJnByFt8W8hhaYzcTM3C', 'ROLE_PATIENT', 'patient27'),
(50, b'1', '$2a$10$FvuhUT86JjgvaUzI0WZAtOX9ffaVxYz0CQEsU8xYeJoeEG.k5qpRu', 'ROLE_PATIENT', 'patient28'),
(51, b'1', '$2a$10$wcmQfWD6MRYhTU3FA0Qmwe1FXzhMeZXElk19bnqkJxVxQAEhIcWt2', 'ROLE_PATIENT', 'patient29'),
(52, b'1', '$2a$10$9TmL5D5Bg1ynJGRkQELL/O5iAcCnoh9BT06L35qYh/lL928Kq3YNC', 'ROLE_PATIENT', 'patient30'),
(53, b'1', '$2a$10$GDYv6E2tAI1tcAya6YDrDe2OrVY96ZgX.MUmDDe7XkND8Q.dE30AW', 'ROLE_PATIENT', 'patient31'),
(54, b'1', '$2a$10$kmC4KcUi0sfaVE49t1k15ezmeHluxn0mwW0V2WUtTiXclcrFg7RKi', 'ROLE_PATIENT', 'patient32'),
(55, b'1', '$2a$10$zQdaQVYWkBIk4R1ltOCdyefVqMxtHmksnLIBIIgFvqfKBvy0BUUYS', 'ROLE_PATIENT', 'patient33'),
(56, b'1', '$2a$10$ywG0Bnp3LOfR1HoRQkjFoODYt6cv19MYvIQOQSM/lAv27KQxsKguK', 'ROLE_PATIENT', 'patient34'),
(57, b'1', '$2a$10$n15HkPIjdXPpKeXLwHyUuOJ7JoDauURoUkv.kz7xGWUO1VxGXOxbG', 'ROLE_PATIENT', 'patient35'),
(58, b'1', '$2a$10$N0JhjfG4YFM87CcUuxupre9U/2B8ALjMyeLl3KfzMRApoQQB7F1PW', 'ROLE_PATIENT', 'patient36'),
(59, b'1', '$2a$10$thPH4lI4ZnsPPG09z4Ucou9Yg/0Lld0rQd5Uo2EtVzd.mZqqAV4Wy', 'ROLE_PATIENT', 'patient37'),
(60, b'1', '$2a$10$KSLlC0eoWLzl096XoVNEOOu/0zwAPBJCE8bTniFR.YThdUnOANmvS', 'ROLE_PATIENT', 'patient38'),
(61, b'1', '$2a$10$8Ea5hkfXbRiqDOmLzMvgmeJD/Hyg/iVgvBQWwhdMm/DlrHGso0leC', 'ROLE_PATIENT', 'patient39'),
(62, b'1', '$2a$10$GdtK5BQD7qxTb4h3b/qkxOAdtH8SlbwuAPTfjEYMxUnSZorxxlL6S', 'ROLE_PATIENT', 'patient40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
