-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2023 at 10:49 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(11) UNSIGNED NOT NULL,
  `age` int(11) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `age`, `first_name`, `last_name`, `user_id`) VALUES
(1, 25, 'Boris', 'Nikolov', 23),
(2, 49, 'Radostina', 'Nikolova', 24),
(3, 55, 'Miglena', 'Antonova', 25),
(4, 33, 'Radka', 'Racheva', 26),
(5, 51, 'Pavel', 'Pavlov', 27),
(6, 28, 'Sofia', 'Viktorova', 28),
(7, 38, 'Kiril', 'Kostadinov', 29),
(8, 35, 'Nikola', 'Stefanov', 30),
(9, 27, 'Nikola', 'Radev', 31),
(10, 26, 'Venera', 'Radeva', 32),
(11, 5, 'Ivo', 'Radev', 33),
(12, 2, 'Eli', 'Radeva', 34),
(13, 38, 'Krasimir', 'Kostov', 35),
(14, 40, 'Vera', 'Kostova', 36),
(15, 51, 'Mehmed', 'Mehmedov', 37),
(16, 48, 'Emine', 'Mehmedova', 38),
(17, 70, 'Boris', 'Denkov', 39),
(18, 68, 'Genoveva', 'Alexandrova', 40),
(19, 32, 'Gabriela', 'Todorova', 41),
(20, 36, 'Todor', 'Todorov', 42),
(21, 11, 'Svilen', 'Stefanov', 43),
(22, 42, 'Adem', 'Erhanov', 44),
(23, 55, 'Trifon', 'Vinarov', 45),
(24, 40, 'Radoslav', 'Radev', 46),
(25, 36, 'Zdravka', 'Radeva', 47),
(26, 12, 'Martin', 'Radev', 48),
(27, 15, 'Ivelina', 'Radeva', 49),
(28, 23, 'Melek', 'Erol', 50),
(29, 37, 'Victoria', 'Pavlova', 51),
(30, 72, 'Vladimir', 'Simeonov', 52),
(31, 31, 'Radomir', 'Rashkov', 53),
(32, 66, 'Zlatina', 'Petrova', 54),
(33, 28, 'Serkan', 'Murat', 55),
(34, 77, 'Ginka', 'Doneva', 56),
(35, 62, 'Kostadin', 'Bonev', 57),
(36, 37, 'Aylin', 'Ademova', 58),
(37, 60, 'Sevda', 'Topalova', 59),
(38, 66, 'Mladen', 'Milev', 60),
(39, 62, 'Ivanka', 'Mileva', 61),
(40, 55, 'Pepa', 'Docheva', 62);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKuwca24wcd1tg6pjex8lmc0y7` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `patients`
--
ALTER TABLE `patients`
  ADD CONSTRAINT `FKuwca24wcd1tg6pjex8lmc0y7` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
